#!/usr/bin/env bash
set -euo pipefail

EXPECTED_HEAD="505a483"
REPO_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$REPO_ROOT"

if ! command -v git >/dev/null 2>&1; then
  echo "ERROR: git not found. Run this inside the Bocholt-Erleben repo." >&2
  exit 1
fi

CURRENT_HEAD="$(git rev-parse --short HEAD 2>/dev/null || true)"
if [[ -z "$CURRENT_HEAD" ]]; then
  echo "ERROR: Not inside a git repo." >&2
  exit 1
fi
if [[ "$CURRENT_HEAD" != "$EXPECTED_HEAD" ]]; then
  echo "ERROR: Expected HEAD $EXPECTED_HEAD but found $CURRENT_HEAD." >&2
  echo "Please switch/update to the validated baseline before applying this package." >&2
  exit 1
fi

required_assets=(
  assets/event-visuals/motif-gap-health-career-fair-01.webp
  assets/event-visuals/motif-gap-fencing-01.webp
  assets/event-visuals/motif-gap-fabric-market-01.webp
  assets/event-visuals/motif-gap-spinning-mill-01.webp
  assets/event-visuals/motif-gap-weaving-mill-01.webp
  assets/event-visuals/motif-gap-darts-01.webp
)
for path in "${required_assets[@]}"; do
  if [[ ! -f "$path" ]]; then
    echo "ERROR: Missing asset $path" >&2
    echo "Unzip the package into the repo root so assets/event-visuals/... exists." >&2
    exit 1
  fi
done

if [[ ! -f data/event_visual_pool.json ]]; then
  echo "ERROR: Missing data/event_visual_pool.json" >&2
  exit 1
fi
if [[ ! -f scripts/build-event-visual-motif-matrix.py ]]; then
  echo "ERROR: Missing scripts/build-event-visual-motif-matrix.py" >&2
  exit 1
fi
if [[ ! -f data/events.tsv ]]; then
  echo "ERROR: Missing data/events.tsv." >&2
  echo "Please place the current Google-Sheet export locally at data/events.tsv and rerun this script." >&2
  exit 1
fi

python3 - <<'PY'
import json
from pathlib import Path

pool_path = Path('data/event_visual_pool.json')
data = json.loads(pool_path.read_text(encoding='utf-8'))

entries = [
    {
        'pool': 'textile_machines_industry',
        'id': 'motif-gap-spinning-mill-01',
        'visual_motif': 'spinning_mill',
        'alt': 'Symbolisches Event-Visual für historische Spinnerei-Führung mit Spinnmaschinen und Besuchergruppe in regionaler Industriekultur-Atmosphäre.'
    },
    {
        'pool': 'textile_machines_industry',
        'id': 'motif-gap-weaving-mill-01',
        'visual_motif': 'weaving_mill',
        'alt': 'Symbolisches Event-Visual für historische Weberei-Führung mit Webstuhl, Maschinen und Besuchergruppe in regionaler Industriekultur-Atmosphäre.'
    },
    {
        'pool': 'indoor_sport_competition',
        'id': 'motif-gap-darts-01',
        'visual_motif': 'darts',
        'alt': 'Symbolisches Event-Visual für lokales Dartturnier mit Spieler an der Abwurflinie und Zuschauergruppe im Vereinsraum.'
    },
    {
        'pool': 'indoor_sport_competition',
        'id': 'motif-gap-fencing-01',
        'visual_motif': 'fencing',
        'alt': 'Symbolisches Event-Visual für regionalen Fechtwettbewerb in einer Sporthalle mit zwei Fechtenden auf der Planche.'
    },
    {
        'pool': 'market_stalls',
        'id': 'motif-gap-fabric-market-01',
        'visual_motif': 'fabric_market',
        'alt': 'Symbolisches Event-Visual für Stoffmarkt mit Stoffrollen, Marktständen und Besucherinnen in kleinstädtischer Außenatmosphäre.'
    },
    {
        'pool': 'business_messe_info',
        'id': 'motif-gap-health-career-fair-01',
        'visual_motif': 'health_career_fair',
        'alt': 'Symbolisches Event-Visual für Gesundheitsberufemesse mit Beratungssituation an Messestand in einer regionalen Veranstaltungshalle.'
    },
]

for entry in entries:
    pool = data['pools'][entry['pool']]
    images = pool.setdefault('images', [])
    image_id = entry['id']
    images[:] = [img for img in images if img.get('id') != image_id]
    images.append({
        'id': image_id,
        'src': f"/assets/event-visuals/{image_id}.webp",
        'status': 'ready',
        'source': 'ai_generated',
        'rights_status': 'ai_generated_symbolic_reviewed',
        'alt': entry['alt'],
        'source_type': 'ai_generated',
        'is_symbolic': True,
        'is_documentary': False,
        'review_status': 'accepted_gap_batch_01_2026_06',
        'card_asset_format': '16:9_webp_1200x675',
        'visual_motif': entry['visual_motif'],
    })

pool_path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('updated', pool_path)
PY

python3 scripts/build-event-visual-motif-matrix.py \
  --events-tsv data/events.tsv \
  --output data/event_visual_motif_matrix.tsv

python3 - <<'PY'
import csv
from collections import Counter
with open('data/event_visual_motif_matrix.tsv', encoding='utf-8', newline='') as handle:
    rows = list(csv.DictReader(handle, delimiter='\t'))
counts = Counter(row['next_action'] for row in rows)
print('=== matrix counts ===')
for key, value in sorted(counts.items()):
    print(f'{key}: {value}')
PY

python3 tools/audit-visual-contract.py --strict

echo
echo "=== status ==="
git status --short

echo
echo "=== staged candidate file set (expected changed/untracked files) ==="
printf '%s\n' \
  assets/event-visuals/motif-gap-health-career-fair-01.webp \
  assets/event-visuals/motif-gap-fencing-01.webp \
  assets/event-visuals/motif-gap-fabric-market-01.webp \
  assets/event-visuals/motif-gap-spinning-mill-01.webp \
  assets/event-visuals/motif-gap-weaving-mill-01.webp \
  assets/event-visuals/motif-gap-darts-01.webp \
  data/event_visual_pool.json \
  data/event_visual_motif_matrix.tsv
