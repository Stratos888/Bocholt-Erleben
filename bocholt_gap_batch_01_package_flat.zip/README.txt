Bocholt erleben – Event Visual Gap Batch 01 Package
Baseline validated for repo HEAD: 505a483

Contents:
- 6 prepared 1200x675 WebP assets under assets/event-visuals/
- apply_gap_batch_01.sh to update pool + rebuild matrix + run audit

Asset mapping:
- motif-gap-health-career-fair-01.webp
- motif-gap-fencing-01.webp
- motif-gap-fabric-market-01.webp
- motif-gap-spinning-mill-01.webp
- motif-gap-weaving-mill-01.webp
- motif-gap-darts-01.webp

How to use in Codespaces (short workflow):
1) Open repo on baseline HEAD 505a483.
2) Unzip this package into the repo root so the included assets land under assets/event-visuals/ and the script lands in the repo root.
3) Ensure the current sheet export exists locally as data/events.tsv (ignored file, not committed).
4) Run:
   bash apply_gap_batch_01.sh
5) If audit is clean, stage intended files, commit, and push.

Expected matrix direction after a successful run:
- ready: 31 -> 37
- gap_to_produce: 35 -> 29
- candidate_to_integrate remains 2

Remaining candidate_to_integrate should still be:
- business_messe_info / info_evening
- open_air_festival / market_square_open_air
